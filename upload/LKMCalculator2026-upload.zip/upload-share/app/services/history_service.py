"""Сервис истории расчётов и сравнений (SQLite)."""

from __future__ import annotations

import json
from datetime import datetime, timezone
from typing import Optional, Sequence

from sqlalchemy import null
from sqlalchemy.orm import Session

from app.infrastructure.database.models import CalculationORM, CalculationLayerORM, ComparisonORM
from app.infrastructure.database.repositories import CalculationRepository
from app.domain.models import SystemCalculationResult, ComparisonResult
from app.domain.surface_profile import SurfaceCondition, SurfacePreparation, SurfaceProfile
from app.domain.normative import UNKNOWN
from app.services.engineering_context_snapshot import (
    engineering_context_from_dict,
    engineering_context_to_dict,
    normative_model_to_dict,
    surface_condition_to_dict,
)
from app.services.snapshot_utils import load_and_verify_snapshot, seal_snapshot
from app.services.tds_normative_bridge import tds_trace_for_material, engineering_context_from_known_tds


class HistoryService:
    def __init__(self, session: Session):
        self.session = session
        self.repo = CalculationRepository(session)

    @staticmethod
    def _material_snapshot(material) -> dict:
        """Capture all material fields needed to restore a calculation independently."""
        def enum_value(value):
            return value.value if hasattr(value, "value") else value

        return {
            "material_id": material.id,
            "material_name": material.material_name,
            "manufacturer": material.manufacturer,
            "brand": material.brand,
            "material_type": enum_value(material.material_type),
            "binder": enum_value(material.binder_type),
            "description": material.description,
            "density": material.density,
            "solids_percent": material.solids_percent,
            "solids_by_volume_percent": material.solids_by_volume_percent,
            "voc": material.voc,
            "color": material.color,
            "ral": material.ral,
            "price_per_kg": material.price_per_kg,
            "price_per_liter": material.price_per_liter,
            "prices_include_vat": material.prices_include_vat,
            "theoretical_coverage": material.theoretical_coverage,
            "application_method": enum_value(material.application_method),
            "min_application_temperature": material.min_application_temperature,
            "max_application_temperature": material.max_application_temperature,
            "min_recoat_time_h": material.min_recoat_time_h,
            "max_recoat_time_h": material.max_recoat_time_h,
            "drying_time_h": material.drying_time_h,
            "full_cure_time_h": material.full_cure_time_h,
            "pot_life_h": material.pot_life_h,
            "induction_time_min": material.induction_time_min,
            "max_relative_humidity": material.max_relative_humidity,
            "min_dew_point_margin_c": material.min_dew_point_margin_c,
            "recommended_dft_min": material.recommended_dft_min,
            "recommended_dft_max": material.recommended_dft_max,
            "max_single_layer_dft": material.max_single_layer_dft,
            "thinner_required": material.thinner_required,
            "thinner_name": material.thinner_name,
            "thinner_percent_min": material.thinner_percent_min,
            "thinner_percent_max": material.thinner_percent_max,
            "thinner_basis": material.thinner_basis,
            "packaging_kg": material.packaging_kg,
            "packaging_l": material.packaging_l,
            "is_two_component": material.is_two_component,
            "datasheet": material.datasheet,
            "datasheet_version": material.datasheet_version,
            "datasheet_date": material.datasheet_date,
            "safety_data_sheet": material.safety_data_sheet,
            "certificate": material.certificate,
            "certificate_version": material.certificate_version,
            "test_protocol": material.test_protocol,
            "is_active": material.is_active,
            "is_incomplete": material.is_incomplete,
            "notes": material.notes,
        }

    @staticmethod
    def _surface_condition_snapshot(obj) -> dict:
        """Normalize legacy object surface inputs into the structured §13 shape.

        Existing Sa/St and roughness values are preserved, but their normative
        assessment remains UNKNOWN until a source-backed rule is attached.
        """
        preparation_value = getattr(obj.preparation, "value", obj.preparation) if obj.preparation else ""
        method = "Sa" if str(preparation_value).startswith("Sa ") else "St" if str(preparation_value).startswith("St ") else "UNKNOWN"
        condition = SurfaceCondition(
            preparation=SurfacePreparation(
                method=method,
                grade=str(preparation_value or ""),
                assessment=UNKNOWN,
            ),
            profile=SurfaceProfile(
                measurement="UNKNOWN",
                nominal_um=obj.roughness,
                assessment=UNKNOWN,
            ),
            substrate=obj.substrate or "",
            contamination_status=UNKNOWN,
            moisture_status=UNKNOWN,
        )
        return surface_condition_to_dict(condition) or {}

    def save_calculation(self, result: SystemCalculationResult, notes: str = "") -> int:
        """Сохранить расчёт как неизменяемый снимок входных данных и результата."""
        obj = result.object_data
        context = result.engineering_context
        explicit_surface = context.surface_condition
        if explicit_surface == SurfaceCondition():
            surface_snapshot = self._surface_condition_snapshot(obj)
        else:
            surface_snapshot = surface_condition_to_dict(explicit_surface) or {}
        snapshot = {
            "snapshot_version": 8,
            "object": {
                "object_name": obj.object_name,
                "customer": obj.customer,
                "project": obj.project,
                "calculation_number": obj.calculation_number,
                "area_m2": obj.area_m2,
                "corrosion_category": obj.corrosion_category.value if obj.corrosion_category else None,
                "durability": obj.durability.value if obj.durability else None,
                "substrate": obj.substrate,
                "surface_type": obj.surface_type.value if obj.surface_type else None,
                "preparation": obj.preparation.value if obj.preparation else None,
                "roughness": obj.roughness,
                "surface_temperature": obj.surface_temperature,
                "air_temperature": obj.air_temperature,
                "relative_humidity": obj.relative_humidity,
                "dew_point": obj.dew_point,
                "dew_point_margin_c": obj.dew_point_margin_c,
                "surface_condition": surface_snapshot,
                "engineering_context": engineering_context_to_dict(context),
                "normative_model": normative_model_to_dict(context.normative_model),
            },
            "system": {
                "name": result.system.system_name,
                "manufacturer": result.system.manufacturer,
                "description": result.system.description,
                "total_dft_min": result.system.total_dft_min,
                "total_dft_target": result.system.total_dft_target,
                "total_dft_max": result.system.total_dft_max,
            },
            "system_name": result.system.system_name,
            "total_dft": result.total_dft,
            "total_cost_per_m2": result.total_cost_per_m2,
            "total_cost": result.total_cost,
            "total_consumption_kg": result.total_practical_consumption_kg,
            "layers": [],
        }
        for lr in result.layers:
            layer = self._material_snapshot(lr.material)
            layer.update({
                "target_dft": lr.target_dft,
                "losses_percent": lr.losses_percent,
                "thinner_percent": lr.thinner_percent,
                "thinner_id": lr.thinner.id if lr.thinner else None,
                "thinner_name": (lr.thinner.material_name if lr.thinner else "") or "",
                "thinner_density": lr.thinner.density if lr.thinner else None,
                "thinner_price_per_kg": lr.thinner.price_per_kg if lr.thinner else None,
                "thinner_price_per_liter": lr.thinner.price_per_liter if lr.thinner else None,
                "thinner_basis": lr.thinner_basis,
                "wft": lr.wft,
                "practical_consumption_kg": lr.practical_consumption_kg,
                "practical_consumption_l": lr.practical_consumption_l,
                "thinner_consumption_kg": lr.thinner_consumption_kg,
                "thinner_consumption_l": lr.thinner_consumption_l,
                "cost_per_m2": lr.cost_per_m2,
                "thinner_cost_per_m2": lr.thinner_cost_per_m2,
                "total_consumption_kg": lr.total_consumption_kg,
                "total_consumption_l": lr.total_consumption_l,
                "total_cost": lr.total_cost,
            })
            mat = lr.material
            mat_name = (mat.material_name or mat.display_name() or "") if mat is not None else ""
            tds = tds_trace_for_material(mat_name)
            tds["layer_number"] = getattr(lr, "layer_number", None) or (len(snapshot["layers"]) + 1)
            layer["tds_trace"] = tds
            snapshot["layers"].append(layer)
        snapshot["tds_traces"] = [layer.get("tds_trace") for layer in snapshot["layers"] if layer.get("tds_trace")]
        snapshot["tds_verified"] = (
            "KNOWN"
            if snapshot["tds_traces"] and all(t.get("tds_verified") == "KNOWN" for t in snapshot["tds_traces"])
            else "UNKNOWN"
        )
        has_known_normative = (
            context is not None
            and context.normative_model is not None
            and bool(context.normative_model.known_rules())
        )
        if not has_known_normative and snapshot["tds_traces"]:
            names = [t.get("material_name") or "" for t in snapshot["tds_traces"]]
            auto_ctx = engineering_context_from_known_tds(
                names, base=context if context is not None else None
            )
            if auto_ctx.normative_model and auto_ctx.normative_model.known_rules():
                snapshot["object"]["engineering_context"] = engineering_context_to_dict(auto_ctx)
                snapshot["object"]["normative_model"] = normative_model_to_dict(auto_ctx.normative_model)
        snapshot = seal_snapshot(snapshot)

        now = datetime.now(timezone.utc)
        calc = CalculationORM(
            calculation_number=obj.calculation_number or "",
            object_name=obj.object_name or "",
            customer=obj.customer or "",
            project=obj.project or "",
            area_m2=obj.area_m2 if obj.area_m2 is not None else null(),
            system_name=result.system.system_name or "Пользовательская",
            total_dft=result.total_dft,
            total_cost_per_m2=result.total_cost_per_m2 if result.total_cost_per_m2 is not None else null(),
            total_cost=result.total_cost if result.total_cost is not None else null(),
            total_consumption_kg=result.total_practical_consumption_kg,
            snapshot_json=json.dumps(snapshot, ensure_ascii=False),
            notes=notes,
            created_at=now,
            updated_at=now,
        )
        for i, lr in enumerate(result.layers):
            layer_snapshot = seal_snapshot(snapshot["layers"][i])
            calc.layers.append(CalculationLayerORM(
                layer_number=i + 1,
                material_name=lr.material.material_name,
                binder=lr.material.binder_type.value if hasattr(lr.material.binder_type, "value") else str(lr.material.binder_type),
                dry_thickness=lr.target_dft,
                consumption_kg=lr.practical_consumption_kg,
                consumption_l=lr.practical_consumption_l,
                cost_per_m2=lr.cost_per_m2 if lr.cost_per_m2 is not None else null(),
                snapshot_json=json.dumps(layer_snapshot, ensure_ascii=False),
            ))
        self.session.add(calc)
        self.session.flush()
        return calc.id

    def list_calculations(self, limit: int = 100) -> Sequence[CalculationORM]:
        return self.repo.list_recent(limit=limit)

    def get_calculation(self, calc_id: int) -> Optional[CalculationORM]:
        return self.repo.get_by_id(calc_id)

    def get_calculation_snapshot(self, calc_id: int) -> dict:
        """Read only a verified sealed snapshot; catalog changes cannot rewrite it."""
        calc = self.get_calculation(calc_id)
        if calc is None:
            raise KeyError(calc_id)
        return load_and_verify_snapshot(calc.snapshot_json)

    def get_calculation_engineering_context(self, calc_id: int):
        """Restore typed engineering context from a verified history snapshot."""
        snapshot = self.get_calculation_snapshot(calc_id)
        object_data = snapshot.get("object", {})
        context_data = object_data.get("engineering_context")
        if context_data:
            return engineering_context_from_dict(context_data)
        legacy_context = {
            "normative_model": object_data.get("normative_model"),
            "surface_condition": object_data.get("surface_condition"),
        }
        return engineering_context_from_dict(legacy_context)

    def delete_calculation(self, calc_id: int) -> None:
        self.repo.delete(calc_id)

    def get_calculation_tds_traces(self, calc_id: int) -> list[dict]:
        snapshot = self.get_calculation_snapshot(calc_id)
        traces = snapshot.get("tds_traces")
        if isinstance(traces, list):
            return list(traces)
        return [t for layer in snapshot.get("layers") or [] if isinstance((t := layer.get("tds_trace")), dict)]

    def get_calculation_tds_verified(self, calc_id: int) -> str:
        snapshot = self.get_calculation_snapshot(calc_id)
        status = snapshot.get("tds_verified")
        if status in ("KNOWN", "UNKNOWN"):
            return status
        traces = self.get_calculation_tds_traces(calc_id)
        return "KNOWN" if traces and all(t.get("tds_verified") == "KNOWN" for t in traces) else "UNKNOWN"

    def save_comparison(self, comparison: ComparisonResult, notes: str = "") -> int:
        snapshot = {
            "snapshot_version": 2,
            "object_name": comparison.object_data.object_name,
            "area_m2": comparison.object_data.area_m2,
            "systems": [
                {
                    "name": s.system.system_name,
                    "total_dft": s.total_dft,
                    "total_cost_per_m2": s.total_cost_per_m2,
                    "total_cost": s.total_cost,
                    "layers_count": len(s.layers),
                }
                for s in comparison.systems
            ],
            "cheapest_index": comparison.cheapest_index,
            "best_balance_index": comparison.best_balance_index,
        }
        snapshot = seal_snapshot(snapshot)
        cmp = ComparisonORM(
            object_name=comparison.object_data.object_name or "",
            area_m2=comparison.object_data.area_m2 if comparison.object_data.area_m2 is not None else null(),
            systems_count=len(comparison.systems),
            snapshot_json=json.dumps(snapshot, ensure_ascii=False),
            notes=notes,
            created_at=datetime.now(timezone.utc),
        )
        self.session.add(cmp)
        self.session.flush()
        return cmp.id

    def get_comparison_snapshot(self, comparison_id: int) -> dict:
        """Read only a verified sealed comparison snapshot."""
        cmp = self.session.get(ComparisonORM, comparison_id)
        if cmp is None:
            raise KeyError(comparison_id)
        return load_and_verify_snapshot(cmp.snapshot_json)

    def list_comparisons(self, limit: int = 50) -> Sequence[ComparisonORM]:
        from sqlalchemy import select
        stmt = select(ComparisonORM).order_by(ComparisonORM.created_at.desc()).limit(limit)
        return self.session.scalars(stmt).all()
